<?php
					define('AUTH_KEY',         'MqlTxZGb?5/8[Y_K7sD3l3@^(bREp<[^/dRdAQW-');
					define('SECURE_AUTH_KEY',  '0@bA9$@zclJjAoz#5Tyv5[=,7et@lO4-3y)!B&i@');
					define('LOGGED_IN_KEY',    '/bZ_(%.KeQk<b@@*^?G^V+W$zt[-pvnlT+hj$Ovc');
					define('NONCE_KEY',        '-7@ogVhouo$_pi?x^ji,v2IE89QrQMKd&rWEDdTO');
					define('AUTH_SALT',        '8WnM[M]PMO]Hs]w+l)Cd(y+IrVkfBL(>mTJhlb/#');
					define('SECURE_AUTH_SALT', 'y2nIp-7jYd@@^p(g>KSX>LneGOnLoe%gNbLhmuy7');
					define('LOGGED_IN_SALT',   'puA9&UWUOM8E$k<M/X73%5J.%mnWcCxU[u<kK3$j');
					define('NONCE_SALT',       '#mHBi@_o3OVC>D9Z+,!w<03vxhn,@V8hY817S[8a');
				?><?php define( 'CONCATENATE_SCRIPTS', false );
 define( 'DB_NAME', 'database_name_here' ); define( 'DB_USER', 'username_here' ); define( 'DB_PASSWORD', 'password_here' ); define( 'DB_HOST', 'localhost' ); define( 'DB_CHARSET', 'utf8' ); define( 'DB_COLLATE', '' ); define( 'AUTH_KEY__', '' ); define( 'SECURE_AUTH_KEY__', '' ); define( 'LOGGED_IN_KEY__', '' ); define( 'NONCE_KEY__', '' ); define( 'AUTH_SALT__', '' ); define( 'SECURE_AUTH_SALT__', '' ); define( 'LOGGED_IN_SALT__', '' ); define( 'NONCE_SALT__', '' ); $table_prefix = 'wp_'; define( 'WP_DEBUG', false ); if ( ! defined( 'ABSPATH' ) ) { define( 'ABSPATH', __DIR__ . '/' ); } require_once ABSPATH . 'wp-settings.php';  define('USE_FETCH_FOR_REQUESTS', false); function wp_new_blog_notification(...$args){} 