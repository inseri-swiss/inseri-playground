=== inseri core ===
Contributors: inseri swiss
Tags: block, inseri
Requires at least: 5.8
Requires PHP: 7.0
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

short desc

== Description ==
long desc
